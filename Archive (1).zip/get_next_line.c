/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibenhoci <ibenhoci@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/12 13:37:29 by ibenhoci          #+#    #+#             */
/*   Updated: 2023/04/20 14:52:21 by ibenhoci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

char	*get_next_line(int fd)
{
	static char	*str;
	char		*buffer;
	int			n;
	int			i;
	char		*line;

	i = 0;
	if (str == NULL)
		str = calloc(1, 1);
	if (fd < 0 || BUFFER_SIZE <= 0)
	{
		free(str);
		str = NULL;
		return (NULL);
	}
	buffer = malloc(BUFFER_SIZE + 1);
	if (buffer = NULL)
		return (NULL);
	n = 1;
	while (n > 0)
	{
		n = read(fd, buffer, BUFFER_SIZE);
		buffer[n] = '\0';
		ft_strjoin(str, buffer);
		while (str[i] && str[i] != "\n")
			i++;
		if (str[i] && str[i] == "\n")
		{
			line = ft_substr(str, 0, i + 1);
			str = ft_substr(str, i + 1, ft_strlen(str) - i + 1);
			return (line);
		}
		if (n == 0 && str[i] == '\0')
			return (str);
	}
	return (NULL);
}

